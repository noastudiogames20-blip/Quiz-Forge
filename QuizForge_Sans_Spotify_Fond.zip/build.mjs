import {build} from 'esbuild';
import {mkdir,copyFile} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
await copyFile('index.html','dist/index.html');
await build({entryPoints:['identity-entry.js'],bundle:true,format:'iife',outfile:'dist/identity.js',minify:true,target:'es2020',platform:'browser'});
