import {getStore} from '@netlify/blobs';
import {getUser} from '@netlify/identity';
const CH=3*1024*1024,ID=/^[A-Za-z0-9_-]{4,80}$/,HEX=/^[a-f0-9]{16,64}$/;
const lim=(k,d,c)=>Math.min(c,Math.max(1,Number(process.env[k])||d))*1048576;
const max=()=>lim('MAX_QUIZ_MB',200,200),quota=()=>lim('USER_QUOTA_MB',500,5000);
const J=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'}});
const E=(s,error,code)=>J({error,code},s);
const hash=async x=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(x)))].map(x=>x.toString(16).padStart(2,'0')).join('');
const rnd=()=>[...crypto.getRandomValues(new Uint8Array(12))].map(x=>x.toString(16).padStart(2,'0')).join('');
export default async req=>{
 const url=new URL(req.url),[a,b,c,d]=url.pathname.replace(/^\/api\/account\/?/,'').split('/'),m=req.method;
 let user;try{user=await getUser()}catch(e){}if(!user)return E(401,'Connexion requise.','AUTH');
 if(m!=='GET'&&req.headers.get('origin')!==url.origin)return E(403,'Origine refusée.');
 const uid=String(user.id||user.sub||user.email||'');if(!uid)return E(401,'Compte invalide.','AUTH');
 const u=(await hash(uid.toLowerCase())).slice(0,40),s=getStore({name:'quizforge-accounts',consistency:'strong'});
 const get=k=>s.get(k,{type:'json'}),idx=async()=>await get('idx/'+u)||{quizzes:[]};
 const drop=async q=>{for(let i=0;i<q.chunks;i++)await s.delete(`data/${u}/${q.id}/${q.version}/${i}`)};
 try{
 if(a==='me'&&m==='GET')return J({id:u,email:user.email||'',name:user.name||''});
 if(a==='library'&&m==='GET'){const x=await idx();return J({quizzes:x.quizzes,used:x.quizzes.reduce((n,q)=>n+q.size,0),quota:quota(),max:max()})}
 if(a==='quiz'&&b==='start'&&m==='POST'){
  const v=await req.json(),qid=String(v.quizId||''),size=Number(v.size);if(!ID.test(qid)||!Number.isInteger(size)||size<22)return E(400,'Taille ou identifiant invalide.');
  if(size>max())return E(413,'Quiz trop volumineux : '+max()/1048576+' Mo maximum.','TOO_BIG');
  const x=await idx(),old=x.quizzes.find(q=>q.id===qid);if(!old&&x.quizzes.length>=100)return E(409,'Limite de 100 quiz atteinte.','QUOTA');
  if(x.quizzes.filter(q=>q.id!==qid).reduce((n,q)=>n+q.size,0)+size>quota())return E(413,'Espace insuffisant dans le compte.','QUOTA');
  const id=rnd(),chunks=Math.ceil(size/CH);await s.setJSON(`up/${u}/${id}`,{id,quizId:qid,size,chunks,got:[],created:Date.now(),name:String(v.name||'Quiz').slice(0,120),questions:Math.max(0,Math.min(1000,Number(v.questions)||0))});return J({uploadId:id,chunk:CH,chunks});
 }
 if(a==='quiz'&&b==='chunk'&&m==='PUT'){
  if(!HEX.test(c||'')||!/^\d+$/.test(d||''))return E(400,'Requête invalide.');const x=await get(`up/${u}/${c}`),n=Number(d);if(!x)return E(404,'Envoi introuvable.');
  if(n>=x.chunks)return E(400,'Morceau hors limites.');const v=new Uint8Array(await req.arrayBuffer()),exp=n===x.chunks-1?x.size-CH*n:CH;
  if(v.length!==exp||n===0&&(v[0]!==80||v[1]!==75))return E(400,'Archive ZIP ou morceau invalide.');
  await s.set(`data/${u}/${x.quizId}/${x.id}/${n}`,v);if(!x.got.includes(n))x.got.push(n);await s.setJSON(`up/${u}/${c}`,x);return J({ok:true});
 }
 if(a==='quiz'&&b==='finish'&&m==='POST'){
  if(!HEX.test(c||''))return E(400,'Requête invalide.');const x=await get(`up/${u}/${c}`);if(!x)return E(404,'Envoi introuvable.');if(new Set(x.got).size!==x.chunks)return E(409,'Morceaux manquants.');
  const li=await idx(),old=li.quizzes.find(q=>q.id===x.quizId);if(li.quizzes.filter(q=>q.id!==x.quizId).reduce((n,q)=>n+q.size,0)+x.size>quota())return E(413,'Espace insuffisant.','QUOTA');
  const entry={id:x.quizId,name:x.name,size:x.size,chunks:x.chunks,version:x.id,updated:Date.now(),questions:x.questions};li.quizzes=[entry,...li.quizzes.filter(q=>q.id!==x.quizId)];await s.setJSON('idx/'+u,li);if(old)await drop(old);await s.delete(`up/${u}/${c}`);return J({ok:true,quiz:entry});
 }
 if(a==='quiz'&&ID.test(b||'')){
  const x=await idx(),q=x.quizzes.find(q=>q.id===b);
  if(c==='meta'&&m==='GET')return q?J({...q,chunk:CH}):E(404,'Quiz introuvable.');
  if(c==='chunk'&&m==='GET'){
   if(!q||!/^\d+$/.test(d||'')||Number(d)>=q.chunks)return E(404,'Morceau introuvable.');
   const v=await s.get(`data/${u}/${q.id}/${q.version}/${Number(d)}`,{type:'arrayBuffer'});return v?new Response(v,{headers:{'content-type':'application/octet-stream','cache-control':'no-store'}}):E(404,'Morceau introuvable.');
  }
  if(c==='delete'&&m==='POST'){if(q){x.quizzes=x.quizzes.filter(x=>x.id!==b);await s.setJSON('idx/'+u,x);await drop(q)}return J({ok:true})}
 }
 if(a==='results'&&m==='GET')return J({results:await get('res/'+u)||[]});
 if(a==='results'&&m==='POST'){
  const x=await req.json();if(!Array.isArray(x.results)||x.results.length>2000)return E(400,'Résultats invalides.');const map=new Map((await get('res/'+u)||[]).map(r=>[r.id,r]));
  for(const r of x.results){if(!r||typeof r.id!=='string'||r.id.length>80)continue;const num=v=>Number.isFinite(+v)?+v:0;map.set(r.id,{id:r.id,quizId:String(r.quizId||'').slice(0,80),quizName:String(r.quizName||'').slice(0,120),date:num(r.date),score:num(r.score),total:num(r.total),pct:Math.max(0,Math.min(100,num(r.pct))),correct:num(r.correct),wrong:num(r.wrong),time:num(r.time)})}
  const results=[...map.values()].sort((a,b)=>b.date-a.date).slice(0,3000);await s.setJSON('res/'+u,results);return J({results});
 }
 if(a==='wipe'&&m==='POST'){
  const x=await idx();for(const q of x.quizzes)await drop(q);const ups=await s.list({prefix:`up/${u}/`});for(const z of ups.blobs){const v=await get(z.key);if(v)await drop({id:v.quizId,version:v.id,chunks:v.chunks});await s.delete(z.key)}
  await s.delete('idx/'+u);await s.delete('res/'+u);return J({ok:true});
 }
 return E(404,'Route inconnue.');
 }catch(e){console.error(e);return E(500,'Erreur interne du service de comptes.')}
};
export const config={path:'/api/account/*'};
