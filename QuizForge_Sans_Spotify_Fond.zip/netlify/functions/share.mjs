import {getStore} from '@netlify/blobs';
const CH=3*1024*1024,TTL=30*86400000,ID=/^[a-z2-7]{12}$/;
const max=()=>Math.min(200,Math.max(1,Number(process.env.SHARE_MAX_MB)||50))*1048576;
const J=(x,status=200)=>new Response(JSON.stringify(x),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
const E=(s,error,code)=>J({error,code},s);
const hash=async x=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(x)))].map(x=>x.toString(16).padStart(2,'0')).join('');
export default async req=>{
 const [a,id,ns]=new URL(req.url).pathname.replace(/^\/api\/share\/?/,'').split('/'),m=req.method,s=getStore({name:'quizforge-shares',consistency:'strong'}),get=k=>s.get(k,{type:'json'});
 try{
 if(a==='start'&&m==='POST'){
  if(process.env.SHARE_CODE&&req.headers.get('x-share-code')!==process.env.SHARE_CODE)return E(401,'Code de partage requis ou incorrect.','AUTH');
  const b=await req.json(),size=Number(b.size);if(!Number.isInteger(size)||size<22)return E(400,'Taille invalide.');if(size>max())return E(413,'Quiz trop volumineux : '+max()/1048576+' Mo maximum pour un partage.');
  const chars='abcdefghijklmnopqrstuvwxyz234567';let id;do{id=[...crypto.getRandomValues(new Uint8Array(12))].map(n=>chars[n%32]).join('')}while(await get('meta/'+id));
  const token=[...crypto.getRandomValues(new Uint8Array(24))].map(n=>n.toString(16).padStart(2,'0')).join(''),chunks=Math.ceil(size/CH),expires=Date.now()+TTL;
  await s.setJSON('meta/'+id,{size,chunks,name:String(b.name||'Quiz').slice(0,80),expires,created:Date.now(),ready:false,tokenHash:await hash(token),got:[]});return J({id,token,chunk:CH,chunks,expires});
 }
 if(!ID.test(id||''))return E(400,'Identifiant invalide.');const x=await get('meta/'+id);if(!x||Date.now()>x.expires)return E(404,'Partage introuvable ou expiré.');
 if(a==='meta'&&m==='GET')return x.ready?J({size:x.size,chunks:x.chunks,chunk:CH,name:x.name,expires:x.expires}):E(404,'Partage incomplet.');
 if(a==='chunk'){
  if(!/^\d+$/.test(ns||'')||Number(ns)>=x.chunks)return E(400,'Morceau hors limites.');const n=Number(ns);
  if(m==='GET'){if(!x.ready)return E(404,'Partage incomplet.');const v=await s.get(`data/${id}/${n}`,{type:'arrayBuffer'});return v?new Response(v,{headers:{'content-type':'application/octet-stream','cache-control':'no-store'}}):E(404,'Morceau introuvable.')}
  if(m==='PUT'){
   if(x.ready)return E(409,'Partage déjà terminé.');if(await hash(req.headers.get('x-token')||'')!==x.tokenHash)return E(403,'Jeton invalide.');
   const v=new Uint8Array(await req.arrayBuffer()),exp=n===x.chunks-1?x.size-n*CH:CH;if(v.length!==exp||n===0&&(v[0]!==80||v[1]!==75))return E(400,'Archive ou morceau invalide.');
   await s.set(`data/${id}/${n}`,v);if(!x.got.includes(n))x.got.push(n);await s.setJSON('meta/'+id,x);return J({ok:true});
  }
 }
 if((a==='finish'||a==='delete')&&m==='POST'){
  if(await hash(req.headers.get('x-token')||'')!==x.tokenHash)return E(403,'Jeton invalide.');
  if(a==='finish'){if(x.ready)return J({ok:true,id,expires:x.expires});if(new Set(x.got).size!==x.chunks)return E(409,'Morceaux manquants.');x.ready=true;delete x.got;await s.setJSON('meta/'+id,x);return J({ok:true,id,expires:x.expires})}
  for(let i=0;i<x.chunks;i++)await s.delete(`data/${id}/${i}`);await s.delete('meta/'+id);return J({ok:true});
 }
 return E(404,'Route inconnue.');
 }catch(e){console.error(e);return E(500,'Erreur interne du service de partage.')}
};
export const config={path:'/api/share/*'};
