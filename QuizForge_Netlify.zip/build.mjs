import { build } from "esbuild";
import { mkdir, copyFile, writeFile } from "node:fs/promises";

await mkdir("dist", { recursive: true });
await copyFile("index.html", "dist/index.html");

/* Module de connexion (Netlify Identity) : si sa construction échoue, le site reste
   déployé et seul le bouton « Compte » affiche un message d'indisponibilité. */
try {
  await build({
    entryPoints: ["identity-entry.js"],
    bundle: true,
    format: "iife",
    outfile: "dist/identity.js",
    minify: true,
    target: "es2020",
    platform: "browser",
    logLevel: "warning",
  });
} catch (err) {
  console.warn("Module de connexion non construit :", err.message);
  await writeFile("dist/identity.js", "window.QFIdentity=null;");
}
