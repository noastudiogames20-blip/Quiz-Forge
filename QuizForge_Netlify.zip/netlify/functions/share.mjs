import { getStore } from "@netlify/blobs";

/*
 * API de partage QuizForge — Netlify Functions + Netlify Blobs.
 * Les quiz sont envoyés en morceaux de 3 Mo pour rester sous la limite de
 * 6 Mo par requête des fonctions Netlify.
 */
const CHUNK = 3 * 1024 * 1024;
const MAX_TOTAL = 50 * 1024 * 1024;
const TTL_MS = 30 * 24 * 3600 * 1000;
const ID_RE = /^[a-z2-7]{12}$/;
const store = () => getStore({ name: "quizforge-shares", consistency: "strong" });

const headers = (extra = {}) => ({
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
  ...extra,
});
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: headers({ "content-type": "application/json; charset=utf-8" }) });
const fail = (status, message, code) => json({ error: message, code }, status);

const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
const sha256 = async (text) => hex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)));
function randomId() {
  const alphabet = "abcdefghijklmnopqrstuvwxyz234567";
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  return [...bytes].map((b) => alphabet[b % 32]).join("");
}
const randomToken = () => hex(crypto.getRandomValues(new Uint8Array(24)).buffer);

async function purgeShare(s, id) {
  const meta = await s.get(`meta/${id}`, { type: "json" });
  if (meta) for (let i = 0; i < meta.chunks; i++) await s.delete(`data/${id}/${i}`);
  await s.delete(`meta/${id}`);
}

async function purgeExpired(s, limit = 10) {
  const { blobs } = await s.list({ prefix: "meta/" });
  let removed = 0;
  for (const b of blobs) {
    if (removed >= limit) break;
    const meta = await s.get(b.key, { type: "json" });
    if (meta && Date.now() > meta.expires) {
      await purgeShare(s, b.key.slice(5));
      removed++;
    }
  }
}

export default async (req, context) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/share\/?/, "").split("/").filter(Boolean);
  const action = parts[0];
  const s = store();

  try {
    if (action === "start" && req.method === "POST") {
      const required = process.env.SHARE_CODE;
      if (required && req.headers.get("x-share-code") !== required) {
        return fail(401, "Code de partage requis ou incorrect.", "AUTH");
      }
      let body;
      try { body = await req.json(); } catch { return fail(400, "Requête invalide."); }
      const size = Number(body.size);
      if (!Number.isInteger(size) || size < 22) return fail(400, "Taille invalide.");
      if (size > MAX_TOTAL) return fail(413, `Quiz trop volumineux : ${Math.floor(MAX_TOTAL / 1048576)} Mo maximum pour un partage.`);
      const chunks = Math.ceil(size / CHUNK);
      const id = randomId();
      const token = randomToken();
      const name = String(body.name || "Quiz").slice(0, 80);
      await purgeExpired(s).catch(() => {});
      await s.setJSON(`meta/${id}`, {
        size, chunks, name, tokenHash: await sha256(token),
        created: Date.now(), expires: Date.now() + TTL_MS, ready: false, got: [],
      });
      return json({ id, token, chunk: CHUNK, chunks, expires: Date.now() + TTL_MS });
    }

    if (action === "chunk") {
      const id = parts[1];
      const n = Number(parts[2]);
      if (!ID_RE.test(id || "") || !Number.isInteger(n) || n < 0) return fail(400, "Identifiant invalide.");
      const meta = await s.get(`meta/${id}`, { type: "json" });
      if (!meta || Date.now() > meta.expires) return fail(404, "Partage introuvable ou expiré.");

      if (req.method === "PUT") {
        if (meta.ready) return fail(409, "Partage déjà terminé.");
        if ((await sha256(req.headers.get("x-token") || "")) !== meta.tokenHash) return fail(403, "Jeton invalide.");
        if (n >= meta.chunks) return fail(400, "Morceau hors limites.");
        const data = new Uint8Array(await req.arrayBuffer());
        const expected = n === meta.chunks - 1 ? meta.size - CHUNK * (meta.chunks - 1) : CHUNK;
        if (data.length !== expected) return fail(400, "Taille du morceau inattendue.");
        if (n === 0 && !(data[0] === 0x50 && data[1] === 0x4b)) return fail(400, "Le fichier doit être une archive ZIP QuizForge.");
        await s.set(`data/${id}/${n}`, data);
        if (!meta.got.includes(n)) meta.got.push(n);
        await s.setJSON(`meta/${id}`, meta);
        return json({ ok: true });
      }

      if (req.method === "GET") {
        if (!meta.ready) return fail(404, "Partage incomplet.");
        if (n >= meta.chunks) return fail(404, "Morceau introuvable.");
        const data = await s.get(`data/${id}/${n}`, { type: "arrayBuffer" });
        if (!data) return fail(404, "Morceau introuvable.");
        return new Response(data, { status: 200, headers: headers({ "content-type": "application/octet-stream" }) });
      }
    }

    if (action === "finish" && req.method === "POST") {
      const id = parts[1];
      if (!ID_RE.test(id || "")) return fail(400, "Identifiant invalide.");
      const meta = await s.get(`meta/${id}`, { type: "json" });
      if (!meta || Date.now() > meta.expires) return fail(404, "Partage introuvable ou expiré.");
      if ((await sha256(req.headers.get("x-token") || "")) !== meta.tokenHash) return fail(403, "Jeton invalide.");
      if (new Set(meta.got).size !== meta.chunks) return fail(409, "Morceaux manquants.");
      meta.ready = true;
      delete meta.got;
      await s.setJSON(`meta/${id}`, meta);
      return json({ ok: true, id, expires: meta.expires });
    }

    if (action === "meta" && req.method === "GET") {
      const id = parts[1];
      if (!ID_RE.test(id || "")) return fail(400, "Identifiant invalide.");
      const meta = await s.get(`meta/${id}`, { type: "json" });
      if (!meta || !meta.ready || Date.now() > meta.expires) return fail(404, "Quiz introuvable ou expiré.");
      return json({ size: meta.size, chunks: meta.chunks, chunk: CHUNK, name: meta.name, expires: meta.expires });
    }

    if (action === "delete" && req.method === "POST") {
      const id = parts[1];
      if (!ID_RE.test(id || "")) return fail(400, "Identifiant invalide.");
      const meta = await s.get(`meta/${id}`, { type: "json" });
      if (!meta) return json({ ok: true });
      if ((await sha256(req.headers.get("x-token") || "")) !== meta.tokenHash) return fail(403, "Jeton invalide.");
      await purgeShare(s, id);
      return json({ ok: true });
    }

    return fail(404, "Route inconnue.");
  } catch (err) {
    console.error("share error", err);
    return fail(500, "Erreur interne du service de partage.");
  }
};

export const config = { path: "/api/share/*" };
