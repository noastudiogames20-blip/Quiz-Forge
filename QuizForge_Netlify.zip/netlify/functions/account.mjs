import { getStore } from "@netlify/blobs";
import { getUser } from "@netlify/identity";

/*
 * Comptes QuizForge — Netlify Identity (connexion) + Netlify Blobs (données).
 * Chaque utilisateur n'accède qu'à ses propres quiz et statistiques.
 * Limites réglables par variables d'environnement : MAX_QUIZ_MB (200 max), USER_QUOTA_MB.
 */
const CHUNK = 3 * 1024 * 1024;
const MAX_QUIZZES = 100;
const MAX_RESULTS = 3000;
const mbEnv = (name, def, ceiling) => Math.min(ceiling, Math.max(1, Number(process.env[name]) || def)) * 1024 * 1024;
const maxQuiz = () => mbEnv("MAX_QUIZ_MB", 200, 200);
const quotaBytes = () => mbEnv("USER_QUOTA_MB", 500, 5000);
const QUIZ_ID = /^[A-Za-z0-9_-]{4,80}$/;
const HEX = /^[a-f0-9]{16,64}$/;
const store = () => getStore({ name: "quizforge-accounts", consistency: "strong" });

const headers = (extra = {}) => ({ "cache-control": "no-store", "x-content-type-options": "nosniff", ...extra });
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: headers({ "content-type": "application/json; charset=utf-8" }) });
const fail = (status, message, code) => json({ error: message, code }, status);
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
const sha256 = async (t) => hex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t)));
const randomHex = (n) => hex(crypto.getRandomValues(new Uint8Array(n)).buffer);
const mo = (n) => Math.round(n / 1048576);

async function dropVersion(s, u, quizId, version, chunks) {
  for (let i = 0; i < chunks; i++) await s.delete(`data/${u}/${quizId}/${version}/${i}`);
}
async function loadIndex(s, u) {
  return (await s.get(`idx/${u}`, { type: "json" })) || { quizzes: [] };
}
const usedBytes = (idx, exceptId) => idx.quizzes.filter((q) => q.id !== exceptId).reduce((a, q) => a + q.size, 0);

async function cleanupUploads(s, u) {
  const { blobs } = await s.list({ prefix: `up/${u}/` });
  for (const b of blobs.slice(0, 20)) {
    const up = await s.get(b.key, { type: "json" });
    if (up && Date.now() - up.created > 24 * 3600 * 1000) {
      await dropVersion(s, u, up.quizId, up.id, up.chunks);
      await s.delete(b.key);
    }
  }
}

export default async (req, context) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/account\/?/, "").split("/").filter(Boolean);
  const method = req.method;

  let user = null;
  try { user = await getUser(); } catch { user = null; }
  if (!user) return fail(401, "Connexion requise.", "AUTH");

  if (method !== "GET") {
    const origin = req.headers.get("origin");
    if (!origin || origin !== url.origin) return fail(403, "Origine refusée.");
  }

  const key = String(user.id || user.sub || user.email || "").toLowerCase();
  if (!key) return fail(401, "Compte invalide.", "AUTH");
  const u = (await sha256(key)).slice(0, 40);
  const s = store();

  try {
    const [a, b, c] = parts;

    if (a === "me" && method === "GET") {
      return json({ id: u, email: user.email || "", name: user.name || user.user_metadata?.full_name || "" });
    }

    if (a === "library" && method === "GET") {
      const idx = await loadIndex(s, u);
      return json({ quizzes: idx.quizzes, used: usedBytes(idx), quota: quotaBytes(), max: maxQuiz() });
    }

    if (a === "quiz" && b === "start" && method === "POST") {
      let body; try { body = await req.json(); } catch { return fail(400, "Requête invalide."); }
      const quizId = String(body.quizId || "");
      const size = Number(body.size);
      if (!QUIZ_ID.test(quizId)) return fail(400, "Identifiant de quiz invalide.");
      if (!Number.isInteger(size) || size < 22) return fail(400, "Taille invalide.");
      if (size > maxQuiz()) return fail(413, `Quiz trop volumineux (${mo(size)} Mo) : ${mo(maxQuiz())} Mo maximum par quiz.`, "TOO_BIG");
      const idx = await loadIndex(s, u);
      const exists = idx.quizzes.some((q) => q.id === quizId);
      if (!exists && idx.quizzes.length >= MAX_QUIZZES) return fail(409, `Limite de ${MAX_QUIZZES} quiz atteinte.`, "QUOTA");
      if (usedBytes(idx, quizId) + size > quotaBytes()) {
        return fail(413, `Espace insuffisant (${mo(quotaBytes())} Mo par compte). Supprimez d'anciens quiz.`, "QUOTA");
      }
      await cleanupUploads(s, u).catch(() => {});
      const id = randomHex(12);
      const chunks = Math.ceil(size / CHUNK);
      await s.setJSON(`up/${u}/${id}`, {
        id, quizId, size, chunks, got: [], created: Date.now(),
        name: String(body.name || "Quiz").slice(0, 120), questions: Math.max(0, Math.min(1000, Number(body.questions) || 0)),
      });
      return json({ uploadId: id, chunk: CHUNK, chunks });
    }

    if (a === "quiz" && b === "chunk" && method === "PUT") {
      const id = parts[2]; const n = Number(parts[3]);
      if (!HEX.test(id || "") || !Number.isInteger(n) || n < 0) return fail(400, "Requête invalide.");
      const up = await s.get(`up/${u}/${id}`, { type: "json" });
      if (!up) return fail(404, "Envoi introuvable.");
      if (n >= up.chunks) return fail(400, "Morceau hors limites.");
      const data = new Uint8Array(await req.arrayBuffer());
      const expected = n === up.chunks - 1 ? up.size - CHUNK * (up.chunks - 1) : CHUNK;
      if (data.length !== expected) return fail(400, "Taille du morceau inattendue.");
      if (n === 0 && !(data[0] === 0x50 && data[1] === 0x4b)) return fail(400, "Le fichier doit être une archive ZIP QuizForge.");
      await s.set(`data/${u}/${up.quizId}/${up.id}/${n}`, data);
      if (!up.got.includes(n)) up.got.push(n);
      await s.setJSON(`up/${u}/${id}`, up);
      return json({ ok: true });
    }

    if (a === "quiz" && b === "finish" && method === "POST") {
      const id = parts[2];
      if (!HEX.test(id || "")) return fail(400, "Requête invalide.");
      const up = await s.get(`up/${u}/${id}`, { type: "json" });
      if (!up) return fail(404, "Envoi introuvable.");
      if (new Set(up.got).size !== up.chunks) return fail(409, "Morceaux manquants.");
      const idx = await loadIndex(s, u);
      const old = idx.quizzes.find((q) => q.id === up.quizId);
      const entry = { id: up.quizId, name: up.name, size: up.size, chunks: up.chunks, version: up.id, updated: Date.now(), questions: up.questions };
      idx.quizzes = [entry, ...idx.quizzes.filter((q) => q.id !== up.quizId)];
      await s.setJSON(`idx/${u}`, idx);
      if (old) await dropVersion(s, u, old.id, old.version, old.chunks);
      await s.delete(`up/${u}/${id}`);
      return json({ ok: true, quiz: entry });
    }

    if (a === "quiz" && QUIZ_ID.test(b || "")) {
      const idx = await loadIndex(s, u);
      const q = idx.quizzes.find((x) => x.id === b);
      if (c === "meta" && method === "GET") {
        if (!q) return fail(404, "Quiz introuvable.");
        return json({ ...q, chunk: CHUNK });
      }
      if (c === "chunk" && method === "GET") {
        const n = Number(parts[3]);
        if (!q || !Number.isInteger(n) || n < 0 || n >= q.chunks) return fail(404, "Morceau introuvable.");
        const data = await s.get(`data/${u}/${q.id}/${q.version}/${n}`, { type: "arrayBuffer" });
        if (!data) return fail(404, "Morceau introuvable.");
        return new Response(data, { status: 200, headers: headers({ "content-type": "application/octet-stream" }) });
      }
      if (c === "delete" && method === "POST") {
        if (q) {
          idx.quizzes = idx.quizzes.filter((x) => x.id !== b);
          await s.setJSON(`idx/${u}`, idx);
          await dropVersion(s, u, q.id, q.version, q.chunks);
        }
        return json({ ok: true });
      }
    }

    if (a === "results" && method === "GET") {
      return json({ results: (await s.get(`res/${u}`, { type: "json" })) || [] });
    }
    if (a === "results" && method === "POST") {
      let body; try { body = await req.json(); } catch { return fail(400, "Requête invalide."); }
      if (!Array.isArray(body.results) || body.results.length > 2000) return fail(400, "Résultats invalides.");
      const clean = [];
      for (const r of body.results) {
        if (!r || typeof r.id !== "string" || r.id.length > 80) continue;
        const num = (v) => (Number.isFinite(+v) ? +v : 0);
        clean.push({
          id: r.id, quizId: String(r.quizId || "").slice(0, 80), quizName: String(r.quizName || "").slice(0, 120),
          date: num(r.date), score: num(r.score), total: num(r.total), pct: Math.max(0, Math.min(100, num(r.pct))),
          correct: num(r.correct), wrong: num(r.wrong), time: num(r.time),
        });
      }
      const cur = (await s.get(`res/${u}`, { type: "json" })) || [];
      const map = new Map(cur.map((r) => [r.id, r]));
      for (const r of clean) map.set(r.id, r);
      const merged = [...map.values()].sort((x, y) => y.date - x.date).slice(0, MAX_RESULTS);
      await s.setJSON(`res/${u}`, merged);
      return json({ results: merged });
    }

    if (a === "wipe" && method === "POST") {
      const idx = await loadIndex(s, u);
      for (const q of idx.quizzes) await dropVersion(s, u, q.id, q.version, q.chunks);
      const ups = await s.list({ prefix: `up/${u}/` });
      for (const x of ups.blobs) {
        const up = await s.get(x.key, { type: "json" });
        if (up) await dropVersion(s, u, up.quizId, up.id, up.chunks);
        await s.delete(x.key);
      }
      await s.delete(`idx/${u}`); await s.delete(`res/${u}`);
      return json({ ok: true });
    }

    return fail(404, "Route inconnue.");
  } catch (err) {
    console.error("account error", err);
    return fail(500, "Erreur interne du service de comptes.");
  }
};

export const config = { path: "/api/account/*" };
