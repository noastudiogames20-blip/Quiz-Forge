import * as Identity from "@netlify/identity";
window.QFIdentity = Identity;
